const express = require("express");
const mysql = require("mysql2");
const cors = require("cors")

const app = express();



app.use(cors());
// app.use(cors({
//     origin: "http://localhost:8081", 
//     credentials: true
// }));

const db = mysql.createConnection({
  user: "root",
  host: "localhost",
  password: "Dhivya@2210",
  database: "dashboard",
});



db.connect((err) => {

  if (err) {

    console.log("mysql error");

  } else {

    console.log("mysql success");

  }

});
db.query(`
  CREATE TABLE IF NOT EXISTS signup_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL
  )
`, (err, results) => {
  if (err) {
    console.error("Error creating 'signup_users' table:", err);
  } else {
    console.log("'signup_users' table created");
  }

});

app.use(express.json());

app.post("/signup", (req, res) => {
  // const username = req.body.username;
  // const email = req.body.email;
  // const password = req.body.password;
  const userdetails = req.body;

  db.query(

    "SELECT * FROM signup_users WHERE username = ? OR email = ?",

    [userdetails.username, userdetails.email],

    (err, results) => {

      if (err) {

        console.log("checking");

        console.error("Error checking existing user details:", err);

        res.status(500).send("Error checking user details");

      } else {

        if (results.length == 0) {

          // Insert user details into the database

          db.query(

            "INSERT INTO signup_users (username, password, email) VALUES (?, ?, ?)",

            [userdetails.username, userdetails.password, userdetails.email],

            (err, insertResults) => {

              if (err) {



                console.log("500");

                res.status(500).send("Error inserting user details");

              } else {

                console.log("User registered successfully");

                res.status(201).send("User registered successfully");

              }

            }

          );

        }

        else {

          // User with the same username or email already exists

          console.log("409");

          res.status(404).send("User already exists");



        }

      }

    }

  );

});


app.post("/login", (req, res) => {
  // const username = req.body.username;
  // const password = req.body.password;

  const userdetails = req.body;

  db.query(

    "SELECT * FROM signup_users where username=? AND password=?",
    [userdetails.username, userdetails.password],
    (err, result) => {
      if (err) {
        console.log(err);
        res.status(500).send("An error occurred while inserting data.");
      }
      else if (result.length > 0) {
        console.log("Login successfully");
        res.status(200).send("Login successfully");

      } else {
        console.log("Invalid credentials");
        res.status(401).send("Invalid credentials");

      }

    }
  )
})

app.post("/projectassign", (req, res) => {
  const projectdetails = req.body;

  db.query(

    "INSERT INTO project_allocation (project_name,start_date,end_date,team_lead,emp_id,project_description) VALUES (?, ?, ?,?,?,?)",

    [projectdetails.project_name, projectdetails.start_date, projectdetails.end_date, projectdetails.team_lead, projectdetails.team_members, projectdetails.project_description],

    (err, insertResults) => {

      if (err) {



        console.log("500");


        res.status(500).send("Error inserting user details");

      } else {

        console.log("User registered successfully");

        res.status(201).send("User registered successfully");

      }

    }

  );
}

);

app.get('/fetchprofile', (req, res) => {
  const { username } = req.query;

  const sql = `SELECT * FROM signup_users WHERE username = ?`;

  db.query(sql, [username], (err, data) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }

    res.json(data);
  });
});

app.get('/api/users', (req, res) => {
  const query = 'SELECT emp_id, name FROM user_details'; 
  db.query(query, [], (err, rows) => { 
    if (err) { console.error(err); 
      res.status(500).json({ error: 'Internal server error' }); 
      return; 
    } 
    console.log("sucess");
    res.status(200).json(rows); 
  }); 
});



app.listen(8081, () => {
  console.log("Server running")
})