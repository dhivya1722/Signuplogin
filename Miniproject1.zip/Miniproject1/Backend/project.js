const express = require("express");
const mysql = require("mysql2");
const cors = require("cors")

const app = express();



app.use(cors());
// app.use(cors({
//     origin: "http://localhost:8081", 
//     credentials: true
// }));

const db = mysql.createConnection({
    user: "root",
    host: "localhost",
    password: "Dhivya@2210",
    database: "dashboard",
});



db.connect((err) => {

    if (err) {

        console.log("mysql error");

    } else {

        console.log("mysql success");

    }

});

app.post("/projectassign",(req,res)=>{
    const projectdetails=req.body;
    
    db.query(

        "SELECT * FROM  WHERE project_name= ? ",
  
        [projectdetails.username],
  
        (err, results) => {
  
          if (err) {
  
              console.log("checking");
  
            console.error("Error checking existing user details:", err);
  
            res.status(500).send("Error checking user details" );
  
          } else {
  
             if(results.length==0) {
  
              // Insert user details into the database
  
              db.query(
  
                "INSERT INTO signup_users (project_name,start_date,end_date,team_lead,emp_id,project_description) VALUES (?, ?, ?,?,?,?)",
  
                [projectdetails.project_name,projectdetails.start_date,projectdetails.end_date,projectdetails.team_lead,projectdetails_project_description],
  
                (err, insertResults) => {
  
                  if (err) {
  
                     
  
                    console.log("500");
  
                    res.status(500).send ("Error inserting user details" );
  
                  } else {
  
                    console.log("User registered successfully");
  
                    res.status(201).send("User registered successfully" );
  
                  }
  
                }
  
              );
  
            }
  
          else{
  
              // User with the same username or email already exists
  
              console.log("409");
  
              res.status(404).send("User already exists" );
  
             
  
            }
  
          }
  
        }
  
      );
  
    });
    app.listen(8081, () => {
        console.log("Server running")
    })