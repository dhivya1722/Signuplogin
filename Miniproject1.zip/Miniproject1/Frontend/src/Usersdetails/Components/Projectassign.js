
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { useState, useEffect } from 'react'
import './Projectassign.css'
import axios from "axios";



function Projectassign() {

    const [project_name, setproject_name] = useState('')
    const [start_date, setstart_date] = useState('')
    const [end_date, setend_date] = useState('')
    const [team_lead, setteam_lead] = useState('')
    const [team_members, setteam_members] = useState('')
    const [project_description, setproject_description] = useState('')
    const [users, setUsers] = useState([]);
    const [users1, setUsers1] = useState([]);
    const [selectedUser, setSelectedUser] = useState([]);
    const [selectedUser1, setSelectedUser1] = useState();


    // onchange for getting userdetails of teamleader
    useEffect(() => {
        async function getdata() {
            const data1 = await axios.get('http://localhost:8081/api/users')
            // console.log(data1);
            setUsers(data1.data)
        };
        getdata();
    }, []);
    const handleUserChange = (event) => { setSelectedUser(event.target.value); }

    // onchange for getting userdetails of teamleader
    useEffect(() => {
        async function getdata() {
            const data1 = await axios.get('http://localhost:8081/api/users')
            // console.log(data1);
            setUsers1(data1.data)
        };
        getdata();
    }, []);
    const handleUserChange1 = (event) => { setSelectedUser1(event.target.value); }




    // function call while clicking button
    function handlesubmit(e) {
        e.preventDefault()
        if (!project_name || !start_date || !end_date || !team_lead || !team_members || !project_description) {
            alert("All fields are required");
            return;
        }
        const projectdetails = {
            project_name,
            start_date,
            end_date,
            team_lead,
            team_members,
            project_description
        };

        console.log(projectdetails)

        axios.post("http://localhost:8081/projectassign", projectdetails)
            .then((response) => {
                console.log(response.data);
                if (response.status === 201) {
                    alert("Registered Successfully");
                } else {
                    alert("Error")
                }
            })
            .catch((error) => {
                // console.error("Error during API call:", error);
                alert("Please enter valid credentials");
            });

    }





    return (

        <div className="container-fluid">
            <div className="row">
                {/* Sidebar */}
                <div className="col-2 sidenav">
                    {/* Sidebar content */}
                    <a className="nav-link text-white" href="#">
                        {/* You can insert an image here */}
                    </a>
                    <a href="#dashboard">Dashboard</a>
                    <a href="/profile">Profile</a>
                    <a href="">Project Allocation</a>
                    {/* ... (other sidebar content) */}
                    <div className="nav-bottom">
                        <span className="bi">Admin</span>
                        <i className="bi bi-box-arrow-right"></i>
                    </div>
                </div>



                {/* Content Area */}
                <div className="col-10" style={{ paddingLeft: '120px', paddingTop: '10px' }}>
                    <div className="container" style={{ marginLeft: '110px' }}>
                        {/* Page title */}
                        {/* <h6>Project Allocation</h6> */}
                        <button
                            type="button"
                            className="btn btn-primary"
                            data-bs-toggle="modal"
                            data-bs-target="#createEventModal"

                        >
                            Project Allocation

                        </button>


                        {/* Create Event Modal */}
                        <div
                            className="modal fade"
                            id="createEventModal"
                            tabIndex="-1"
                            aria-labelledby="exampleModalLabel"
                            aria-hidden="true"

                        >
                            <div className="modal-dialog">
                                <div className="modal-content">
                                    <div className="modal-header">
                                        <h5 className="modal-title" id="exampleModalLabel">
                                            Project Allocation
                                        </h5>
                                        <button
                                            type="button"
                                            className="btn-close"
                                            data-bs-dismiss="modal"
                                            aria-label="Close"
                                        ></button>
                                    </div>
                                    <div className="modal-body">

                                        <label htmlFor="pro_name">Project Name</label>
                                        <input type="text" className="pro_name" id="pro_id" name={project_name} onChange={event => setproject_name(event.target.value)}></input>

                                        <label htmlFor="start_date">Start Date</label>
                                        <input type="date" className="s_date" id="s_id" name={start_date} onChange={event => setstart_date(event.target.value)}></input>

                                        <label htmlFor="end__date">End Date</label>
                                        <input type="date" className="e_date" id="e_id" name={end_date} onChange={event => setend_date(event.target.value)}></input>

                                        <label htmlFor="team_leader">Team Leader</label>
                                        <select value={selectedUser1} onChange={(event) => { handleUserChange1(event); setteam_lead(event.target.value) }}>
                                            <option value="">Select  the team leader</option>
                                            {users1.map(user => (<option key={user.emp_id} value={user.emp_id}> {user.name} </option>))}
                                        </select>



                                        <label htmlFor="team_members">Team Members</label>
                                        <select
                                            id="team_members"
                                            value={team_members}
                                            onChange={(event) => setteam_members(event.target.value)}
                                        >
                                            <option value="">Select Team Member</option>
                                            {users.map((user) => (
                                                <option key={user.emp_id} value={user.emp_id}>
                                                    {user.name}
                                                </option>
                                            ))}
                                        </select>




                                        <div className="description-wrapper">
                                            <label htmlFor="end__date">Description</label><br></br>
                                            <textarea className="info" id="description" rows="5" cols="60" name={project_description} onChange={event => setproject_description(event.target.value)}></textarea>
                                        </div>
                                    </div>

                                    {/* Form Submit button */}

                                    <div className="modal-footer">
                                        <button
                                            type="button"
                                            className="btn btn-secondary"
                                            data-bs-dismiss="modal"
                                        >
                                            Close
                                        </button>
                                        <button type="button" className="btn btn-primary" onClick={handlesubmit}>Assign Project</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );

}



export default Projectassign;