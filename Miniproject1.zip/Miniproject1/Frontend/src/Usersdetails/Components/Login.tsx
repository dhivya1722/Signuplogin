import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import './Login.css'
import image from './bgimage.png';








//Typescript interface
interface Loginuser {
    username: string;
    password: string;
}


function Login() {

    //navigate to specified path

    const navigate = useNavigate();

  //Usestate for each details of user
    const [username, setusername] = useState('')
    const [password, setpassword] = useState('')

    function handlesubmit() {

   // Empty field not accepted
        if (!username || !password) {
            alert("All fields are required");
            return;
        }

        const userdetails: Loginuser = {
            username,
            password,
        };

    

    //api called
    axios.post("http://localhost:8081/login", userdetails)
        .then((response) => {
            console.log(response.data); 
            if(response.status===200){
                const user = response.data;
                localStorage.setItem("Username",userdetails.username);
            alert("Login successfully ");
            // navigate("/profilepage");
            navigate("/projectassign")
            }else{
                alert("error")

            }
        })
        .catch((error) => {
            alert("Invalid credentials");
        });


    }

//LOCAL STORAGE

    //     const existingUsersJSON = localStorage.getItem('users');
    //     const existingUsers: Loginuser[] = existingUsersJSON ? JSON.parse(existingUsersJSON) : [];
    //     const user = existingUsers.find(userdetails => userdetails.username === username && userdetails.password === password);
    //     existingUsers.push(userdetails);
    //     console.log('loginuser', userdetails);




    //     if (user) {
    //         localStorage.setItem('user', JSON.stringify(user));
    //         console.log('User logged in:', user);
    //         alert("user logged in")
    //         navigate("/dashboard");
    //     }

       
    //     else {
    //         alert('Invalid email or password');
    //     }
    // }





    return (
        <div className="main">
            <div className="header">
            <h1 className="jin">JIN Connected Apps</h1>
            <img src={image}></img> 
            </div>

        <div className="loginform">
       
                <h2>Login form</h2>
                <div className="user">
                <label >Username </label>
                <input type="username" className="u_name" value={username} onChange={event => setusername(event.target.value)} required></input>
                </div>

                <div className="pass">
                <label >Password </label>
                <input type="password" className="pass" value={password} onChange={event => setpassword(event.target.value)} required></input>
                </div>

                <div className="loginbutton">
                <button className="button" onClick={handlesubmit}>Login</button>
                </div>


                <p> Don't have an account?<Link to="/signup"> Signup</Link> </p>
            
        </div>
        <div className="footer">
            {/* <p >Powered by JMAN Group</p><p>2023 © Copyright</p> */}
        </div>
        </div>

    )

}
export default Login;