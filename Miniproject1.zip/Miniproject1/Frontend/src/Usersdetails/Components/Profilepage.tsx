
// import image from './img_avatar.png';
// import { useEffect, useState } from 'react';s
import { useEffect, useState } from 'react';
import './Profilepage.css'
import { useNavigate } from 'react-router-dom';





interface UserData {
    username: string;
    email: string;
    password: string
}

function Profilepage() {


    const navigate = useNavigate();

    const [username, setusername] = useState<string | null>(null);

    const [userData, setUserData] = useState<UserData | null>(null);



    useEffect(() => {

        const storedUsername = localStorage.getItem('Username');

        console.log(storedUsername)

        if (storedUsername) {

            setusername(storedUsername);

            // Fetch user details based on stored email

            fetch(`http://localhost:8081/fetchprofile?username=${storedUsername}`)

            

                .then(res => res.json())

                .then(data => {


                    console.log(data)

                    if (data.length > 0) {

                        setUserData(data[0]); // Assuming the first record is the user's details

                    }

                })

                .catch(err => console.log(err));

        }

    }, []);

    // const [userData, setUserData] = useState(null);

    // useEffect(() => {
    //     // Retrieve user data from local storage
    //     const loggedInUserJSON = localStorage.getItem('loggedInUser');
    //     const loggedInUser = loggedInUserJSON ? JSON.parse(loggedInUserJSON) : null;
    //     setUserData(loggedInUser);
    // }, []);





    return (

        <div className="dashboard-container">

            <div className="main-content">

      

                <h2>User Profile</h2>

               

                {userData && (

                    <div>

                        <div className="img">

                     

                        </div>

                      

                        <p>Name: {userData.username}</p>

                        <p>Email: {userData.email}</p>

                        <p>password: {userData.password}</p>

                     
 

 

 

 

                       

                    </div>

                )}

               

            </div>

        </div>

    );

}

 




 export default Profilepage;
