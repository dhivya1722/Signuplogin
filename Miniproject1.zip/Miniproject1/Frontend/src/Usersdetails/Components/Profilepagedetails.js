import React from 'react';
import './Profilepagedetails.css';

function Profilepagedetails() {
    return (
        <div className='main'>
            <div className="form-container">
                <h1>Welcome to Profile page register</h1>

                <div className="user">
                    <label>Name</label>
                    <input type="text" className="name" />
                </div>

                <div className="user">
                    <label>Username</label>
                    <input type="text" className="u_name" />
                </div>

                <div className="email">
                    <label>Email</label>
                    <input type="email" className="email" />
                </div>

                <div className="designation">
                    <label>Designation</label>
                    <input type="text" className="role" />
                </div>

                <div className="pass">
                    <label>Password</label>
                    <input type="password" className="pass" />
                </div>

                <div className="DOB">
                    <label>Date Of Birth</label>
                    <input type="date" className="dob" />
                </div>

                <div className="p_no">
                    <label>Mobile Number</label>
                    <input type="tel" className="m_no" />
                </div>


                <div>
                    <button type="button">Submit</button>
                </div>
            </div>
        </div>
    );
}

export default Profilepagedetails;
