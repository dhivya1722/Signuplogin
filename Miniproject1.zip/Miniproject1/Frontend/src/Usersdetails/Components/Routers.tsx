import React from 'react';
import { BrowserRouter as Router, Routes,Route} from "react-router-dom";
import Login from './Login';
import Signup from './Signup';
import Projectassign from './Projectassign';
import Profilepage from './Profilepage';
import Profilepagedetails from './Profilepagedetails';





const Routers: React.FC = () => {
  return (
    <Router>
        <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup/>} />
            <Route path="/projectassign" element={<Projectassign/>} />
            <Route path="/profilepage" element={<Profilepage/>} />
            <Route path="/profilepagedetails" element={<Profilepagedetails/>} />

            
            
        </Routes>
    </Router>
  );
};

export default Routers;