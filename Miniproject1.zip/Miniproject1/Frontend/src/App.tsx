
import './App.css';
import Routers from './Usersdetails/Routers';

function App() {
  return (
    <div >
     <Routers />
    </div>
  );
}

export default App;
